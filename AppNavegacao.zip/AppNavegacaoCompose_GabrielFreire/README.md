# AppNavegacaoCompose
Navegação com Compose


TELA 1

![Captura de tela 2023-09-26 162554](https://github.com/JoaoEnrique13/AppNavegacaoCompose/assets/99426704/5d94e7d0-10b6-4789-b531-e696a2578ee7)

TELA 2

![Captura de tela 2023-09-26 162616](https://github.com/JoaoEnrique13/AppNavegacaoCompose/assets/99426704/8b143908-9678-4f18-aa8b-1bae40c9b7c1)
